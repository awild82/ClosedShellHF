%Partner function to bohr2ang
function y = ang2bohr(x)
    y = x/0.52917721067;
end