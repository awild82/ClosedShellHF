%Takes a scalar, x, and returns the semifactorial of x
function xfac2 = fact2(x)
    xfac2 = prod(x:-2:1);
end



